<?php
/*
 * Plugin Name: OSS Upload
 * Version: 4.4
 * Description: Upload with Aliyun OSS, with modified OSS Wrapper and fully native image edit function support.
 * Plugin URI: https://www.xiaomac.com/2016121895.html
 * Author: Link
 * Author URI: https://www.xiaomac.com
 * Text Domain: oss-upload
 * Domain Path: /lang
 * Network: true
*/

add_action("\x69\156\151\164","\x4f\x55\x31\x31\x34\x30",1);
function OU1140(){
if(!OU1141("\x6f\163\x73")||!OU1141("\157\163\x73\x5f\141\x6b\x65\x79")||!OU1141("\157\x73\163\x5f\163\153\145\x79")||!OU1141("\157\163\163\x5f\x65\x6e\x64\160\x6f\x69\x6e\164")||!OU1141("\x6f\163\x73\137\160\141\x74\x68"))return;
define("\117\123\x53\x5f\x41\x43\x43\x45\x53\x53\x5f\x49\104",trim(OU1141("\x6f\x73\x73\x5f\x61\x6b\x65\171")));
define("\117\123\x53\x5f\101\x43\x43\x45\x53\x53\x5f\113\x45\x59",trim(OU1141("\x6f\x73\x73\137\x73\153\x65\171")));
define("\117\x53\x53\x5f\x45\x4e\x44\120\x4f\111\x4e\124",trim(OU1141("\x6f\x73\x73\x5f\145\156\144\x70\157\151\156\x74")));
require_once("\x6c\x69\x62\x2f\117\123\x53\x57\x72\x61\x70\x70\145\x72\56\160\x68\x70");
OU1142();
if(OU1141("\157\x73\163\x5f\162\x65\x6d\x6f\164\x65")){
add_action("\x70\157\x73\164\x5f\163\x75\142\155\x69\x74\x62\157\x78\x5f\155\x69\x73\x63\x5f\x61\143\x74\x69\x6f\156\x73","\117\125\61\x31\x37\x34");
if(!empty($_POST["\x6f\x73\x73\x5f\165\160\154\157\141\x64\x5f\x72\145\155\x6f\164\x65"]))add_filter("\143\x6f\156\164\x65\x6e\x74\x5f\163\141\x76\x65\137\x70\x72\x65","\x4f\125\x31\61\x37\x35");
}
}

function OU1141($OU1001,$OU1002=null){
if(!$OU1003=get_option("\157\165\157\160"))$OU1003=get_site_option("\x6f\x75\157\160");
return isset($OU1003[$OU1001])?(isset($OU1002)?$OU1003[$OU1001]==$OU1002:$OU1003[$OU1001]):'';
}

function OU1142(){
add_filter("\x75\x70\x6c\x6f\141\x64\x5f\x64\x69\x72","\117\125\x31\x31\x34\67");
}

function OU1143(){
if(!defined("\x4f\x53\123\x5f\101\x43\x43\x45\123\x53\x5f\x49\104"))return false;
$OU1004=isset($_GET["\x61\x63\x74\151\x6f\x6e"])?$_GET["\141\143\x74\151\157\x6e"]:(isset($_POST["\x61\143\x74\x69\157\x6e"])?$_POST["\x61\x63\x74\x69\x6f\x6e"]:'');
return in_array($OU1004,array("\x75\x70\x6c\x6f\x61\x64\55\x70\154\165\147\x69\156","\165\x70\x6c\157\x61\x64\x2d\x74\x68\x65\x6d\145"))?false:true;
}

function OU1144($OU1005){
return strtoupper(substr(PHP_OS,0,3))=="\x57\111\116"?iconv("\x75\164\x66\x2d\x38","\x67\x62\153\57\x2f\x49\107\x4e\117\x52\x45",$OU1005):$OU1005;
}

function OU1145($OU1006){
return basename(parse_url($OU1006,PHP_URL_PATH));
}

function OU1146(){
if(!OU1141("\x6f\163\163\x5f\x77\145\142\160")||wp_is_mobile())return 0;
return isset($_SERVER["\x48\x54\x54\x50\x5f\101\x43\x43\x45\x50\124"])&&stripos($_SERVER["\110\124\x54\x50\x5f\x41\103\103\x45\x50\x54"],"\x2f\x77\x65\142\x70")?1:0;
}

function OU1147($OU1007){
if(!OU1143())return $OU1007;
if(OU1141("\x6f\x73\x73")&&OU1141("\157\x73\x73\x5f\160\x61\164\x68")&&OU1141("\x6f\163\x73\x5f\x75\162\x6c")){
$OU1010=trim(OU1141("\x6f\x73\x73\x5f\160\141\x74\x68"),"\x2f");
if(empty($OU1007["\x64\145\146\x61\x75\x6c\x74"])&&$OU1007["\x62\141\x73\x65\x64\x69\162"]!=$OU1010)$OU1007["\x64\x65\x66\x61\x75\x6c\164"]=$OU1007;
$OU1007["\x62\x61\x73\x65\x64\x69\x72"]=$OU1010;
$OU1007["\x70\x61\x74\150"]=$OU1007["\x62\x61\x73\x65\x64\x69\162"].$OU1007["\x73\x75\142\x64\x69\x72"];
$OU1007["\142\x61\163\145\165\x72\x6c"]=trim(OU1141("\x6f\163\x73\x5f\165\x72\154"),"\x2f");
$OU1007["\165\x72\154"]=$OU1007["\x62\141\163\145\x75\x72\154"].$OU1007["\x73\165\x62\x64\x69\x72"];
}
return $OU1007;
}

function OU1150($OU1011,$OU1012=false){
if(!is_dir($OU1011))return false;
$OU1013=array();
$OU1014=scandir($OU1011);
foreach($OU1014 as $OU1006){
if($OU1006=="\56"||$OU1006=="\56\56")continue;
$OU1015=rtrim($OU1011,"\57")."\x2f".$OU1006;
if(is_dir($OU1015)){
if($OU1012&&$OU1016=OU1150($OU1015,$OU1012))$OU1013=array_merge($OU1013,$OU1016);
}else{
$OU1013[]=$OU1015;
}
}
return $OU1013;
}

add_filter("\x77\x70\137\150\x61\x6e\144\x6c\145\137\x75\160\x6c\x6f\x61\144\x5f\x70\x72\145\146\151\154\164\x65\162","\x4f\x55\x31\61\x35\61");
function OU1151($OU1006){
if(!OU1143())return $OU1006;
$OU1017=OU1147(wp_get_upload_dir());
$OU1006["\x6e\x61\x6d\145"]=wp_unique_filename($OU1017["\144\x65\x66\141\x75\x6c\164"]["\x70\x61\x74\x68"],OU1144($OU1006["\x6e\x61\x6d\x65"]));
$OU1006["\156\x61\155\x65"]=wp_unique_filename($OU1017["\x70\x61\x74\x68"],OU1144($OU1006["\x6e\x61\155\145"]));
if(isset($OU1006["\x73\x69\172\x65"])&&$OU1006["\x73\x69\172\145"]>=1024*1024){
remove_filter("\x75\x70\x6c\157\141\144\x5f\x64\x69\x72","\117\x55\61\x31\64\67");
}else if(OU1141("\x6f\x73\x73\x5f\142\141\x63\x6b\x75\x70")){
@copy($OU1006["\164\155\x70\137\x6e\x61\x6d\x65"],$OU1017["\x64\x65\x66\141\x75\x6c\x74"]["\x70\x61\x74\x68"]."\x2f".$OU1006["\x6e\x61\x6d\x65"]);
}
return $OU1006;
}

add_filter("\x77\x70\x5f\x68\141\x6e\x64\154\x65\x5f\165\x70\154\x6f\x61\x64","\x4f\x55\x31\61\x35\x32",9999,2);
function OU1152($OU1006,$OU1020="\x75\x70\x6c\157\x61\x64"){
if(!has_filter("\165\x70\x6c\157\x61\x64\x5f\x64\x69\x72","\117\125\x31\x31\64\x37")){
OU1153($OU1006["\x66\151\154\145"]);
OU1142();
}
return $OU1006;
}

function OU1153($OU1006,$OU1021=true){
if(!OU1143())return;
$OU1017=OU1147(wp_get_upload_dir());
$OU1010=explode("\x2f",substr($OU1017["\x62\141\x73\145\x64\x69\x72"]."\57",6),2);
$OU1022=str_replace($OU1017["\144\x65\146\x61\165\x6c\x74"]["\x62\x61\x73\145\x64\151\162"]."\57",'',$OU1006);
try{
@set_time_limit(0);
$OU1023=new OU_ALIOSS;
$OU1024=$OU1023->create_mpu_object($OU1010[0],$OU1010[1].$OU1022,array("\x66\x69\x6c\x65\x55\x70\x6c\x6f\x61\x64"=>$OU1006));
if(isset($_SESSION["\157\163\163\x5f\x75\160\154\157\x61\144\x5f\145\x72\x72\157\x72"]))unset($_SESSION["\x6f\x73\163\x5f\165\x70\154\157\x61\144\x5f\x65\162\x72\x6f\x72"]);
if($OU1024->isOK())return $OU1017["\x62\x61\x73\x65\144\x69\x72"]."\57".$OU1022;
}catch(Exception $OU1025){
if($OU1021&&@file_exists($OU1006))@unlink($OU1006);
$_SESSION["\x6f\x73\x73\137\165\x70\x6c\x6f\x61\x64\137\x65\x72\x72\x6f\x72"]=$OU1006."\x3c\x62\x72\x2f\76".$OU1025->getMessage();
}
return false;
}

function OU1154($OU1026,$OU1027){
$OU1026["\x72\x65\152\145\143\x74\137\x75\x6e\x73\x61\146\145\x5f\x75\x72\154\x73"]=false;
$OU1026["\x68\x65\141\x64\145\x72\x73"]=array("\122\x65\x66\x65\x72\x65\162"=>$OU1027);
return $OU1026;
}

add_filter("\x66\151\x6c\x65\x73\171\x73\x74\145\155\x5f\x6d\145\x74\x68\157\x64","\x4f\125\x31\x31\65\x35",10,4);
function OU1155($OU1030,$OU1026,$OU1020,$OU1031){
return OU1141("\x6f\163\x73")?"\x64\151\x72\145\x63\164":$OU1030;
}

add_filter("\x5f\x77\x70\137\x72\x65\x6c\141\164\x69\x76\x65\x5f\x75\x70\x6c\x6f\x61\x64\137\160\x61\x74\150","\x4f\x55\61\x31\x35\66",10,2);
function OU1156($OU1032,$OU1022){
if(OU1141("\157\163\x73")){
$OU1017=wp_get_upload_dir();
$OU1032=str_replace(array($OU1017["\142\141\x73\145\x64\x69\x72"]."\57",$OU1017["\x64\x65\x66\141\x75\x6c\x74"]["\x62\x61\x73\x65\144\151\x72"]."\x2f"),'',$OU1032);
}
return $OU1032;
}

function OU1157($OU1011){
$OU1017=wp_get_upload_dir();
return str_replace($OU1017["\142\x61\x73\x65\144\x69\x72"],$OU1017["\x64\x65\146\x61\x75\x6c\x74"]["\x62\x61\163\x65\144\x69\x72"],$OU1011);
}

function OU1160($OU1027){
$OU1017=wp_get_upload_dir();
return str_replace($OU1017["\142\x61\x73\x65\x75\x72\x6c"],$OU1017["\x64\x65\146\141\x75\154\x74"]["\x62\x61\163\x65\x75\x72\x6c"],$OU1027);
}

add_action("\x61\146\x74\x65\x72\x5f\x73\x65\x74\x75\x70\x5f\x74\150\x65\155\x65","\x4f\125\x31\x31\66\61",11);
function OU1161(){
load_plugin_textdomain("\x6f\x73\x73\x2d\165\160\154\x6f\x61\144",false,"\157\163\x73\x2d\x75\160\154\x6f\x61\x64\x2f\x6c\x61\156\147");
if(($OU1033=OU1141("\x6f\x73\x73\137\x73\151\x7a\145\x5f\x77\151\x64\x74\150"))&&($OU1034=OU1141("\157\x73\x73\x5f\x73\x69\x7a\x65\x5f\x68\x65\x69\147\x68\164"))){
add_theme_support("\160\157\x73\x74\x2d\164\x68\x75\x6d\x62\x6e\x61\x69\154\x73");
set_post_thumbnail_size(intval($OU1033),intval($OU1034),array("\x63\x65\156\164\x65\162","\143\x65\156\x74\x65\x72"));
}
}

add_action("\x61\x64\155\151\x6e\x5f\x69\156\x69\x74","\x4f\x55\x31\61\x36\62",1);
function OU1162(){
register_setting("\x6f\x73\x73\137\165\160\x6c\157\141\x64\137\141\144\x6d\x69\x6e\x5f\x6f\x70\x74\151\x6f\156\163\137\x67\x72\x6f\x75\x70","\x6f\x75\x6f\160");
if(!OU1141("\x6f\x73\x73"))return;
add_filter("\167\160\x5f\x70\x72\151\x76\141\143\171\x5f\x65\x78\160\157\x72\x74\x73\x5f\x64\151\162","\x4f\x55\61\61\x35\67");
add_filter("\x77\x70\x5f\160\x72\x69\x76\x61\143\x79\x5f\145\x78\x70\157\162\x74\x73\137\165\x72\154","\x4f\125\61\61\x36\x30");
}

add_action("\x61\x64\x6d\x69\156\x5f\x6d\145\156\x75","\x4f\125\x31\x31\x36\63");
function OU1163(){
$OU1035=__('OSS Upload','oss-upload');
add_options_page($OU1035,$OU1035,"\155\141\x6e\x61\x67\x65\x5f\x6f\x70\164\x69\x6f\x6e\163","\157\x73\x73\x2d\165\x70\154\157\x61\x64","\117\x55\x31\62\x31\x35");
}

add_filter("\166\x69\x65\x77\x73\x5f\x75\x70\x6c\x6f\x61\144","\x4f\x55\61\x31\x36\64");
function OU1164($OU1036){
$OU1037=OU1172("\x6f\x70\164\x69\x6f\x6e\x73\55\147\x65\156\145\x72\141\x6c\56\160\x68\x70\77\160\x61\x67\x65\x3d\x6f\x73\x73\x2d\x75\160\154\157\141\x64",__('OSS Upload','oss-upload'),"\x62\x75\x74\164\x6f\x6e");
if(is_super_admin())$OU1036["\141\x63\x74\151\x6f\x6e\x73"]=$OU1037;
return $OU1036;
}

add_filter("\160\x6c\x75\147\x69\x6e\x5f\x61\x63\x74\x69\x6f\x6e\x5f\x6c\151\156\x6b\x73\x5f".plugin_basename(__FILE__),"\x4f\x55\61\61\66\65");
function OU1165($OU1040){
if(is_multisite()&&(!is_main_site()||!is_super_admin()))return $OU1040;
$OU1041=array(OU1172("\x6f\160\164\x69\x6f\x6e\x73\x2d\147\x65\x6e\x65\162\141\154\x2e\x70\x68\160\x3f\160\141\x67\145\x3d\x6f\x73\x73\x2d\x75\x70\x6c\x6f\x61\x64",__('Settings','oss-upload')));
return array_merge($OU1041,$OU1040);
}

add_action("\165\x70\x64\x61\164\145\x5f\x6f\160\x74\151\x6f\x6e\x5f\x6f\x75\157\x70","\x4f\x55\x31\x31\x36\x36",10,3);
function OU1166($OU1042,$OU1043,$OU1044){
if(is_multisite()&&(!is_main_site()||!is_super_admin()))return;
update_site_option($OU1044,$OU1043);
}

function OU1167($OU1045){
$OU1046=get_plugin_data(__FILE__);
return isset($OU1046)&&is_array($OU1046)&&isset($OU1046[$OU1045])?$OU1046[$OU1045]:'';
}

function OU1170($OU1047,$OU1050=false){
static $OU1051=array();
$OU1052=get_user_option("\x6d\x61\156\x61\x67\x65\x73\145\x74\x74\x69\x6e\147\163\x5f\x70\x61\x67\x65\x5f\157\163\163\x2d\x75\x70\154\x6f\141\x64\x63\x6f\x6c\x75\x6d\156\163\150\151\x64\x64\x65\156");
$OU1053=(is_array($OU1052)&&in_array($OU1047,$OU1052))?"\x20\x68\151\x64\x64\x65\x6e":'';
$OU1054=in_array($OU1047,$OU1051)?" class='{$OU1047}":" id='{$OU1047}' class='manage-column";
$OU1055="{$OU1054} column-{$OU1047}{$OU1053}'";
if(!in_array($OU1047,$OU1051))$OU1051[]=$OU1047;
if($OU1050)return $OU1055;
echo $OU1055;
}

add_filter("\x6d\141\x6e\x61\x67\x65\137\x73\x65\x74\x74\151\x6e\x67\x73\x5f\x70\x61\x67\x65\x5f\x6f\163\x73\x2d\x75\x70\x6c\x6f\141\x64\137\x63\x6f\x6c\x75\x6d\x6e\163","\117\x55\x31\61\x37\61");
function OU1171($OU1047){
$OU1047["\x5f\164\x69\164\x6c\145"]=__('Show More','oss-upload');
$OU1047["\x6f\x73\x73\x5f\x75\x70\x6c\x6f\141\x64\x5f\x64\x65\163\x63"]=__('Descriptions','oss-upload');
$OU1047["\x6f\x73\x73\137\165\x70\154\x6f\x61\x64\x5f\x65\170\x61\x6d\x70\x6c\x65"]=__('Examples','oss-upload');
return $OU1047;
}

function OU1172($OU1027,$OU1056='',$OU1057=''){
if(empty($OU1056))$OU1056=$OU1027;
$OU1060=stripos($OU1057,"\x62\x75\x74\x74\x6f\x6e")!==false?"\x20\x63\x6c\x61\x73\x73\x3d\x27\x62\x75\164\x74\157\x6e\x27":"";
$OU1061=stripos($OU1057,"\x62\x6c\141\156\x6b")!==false?"\40\x74\x61\x72\x67\x65\x74\x3d\x27\137\142\154\x61\x6e\x6b\47":"";
$OU1037="<a href='{$OU1027}'{$OU1060}{$OU1061}>{$OU1056}</a>";
return stripos($OU1057,"\x70")!==false?"<p>{$OU1037}</p>":"{$OU1037} ";
}

add_action("\x77\x70\x5f\145\156\x71\165\x65\x75\x65\x5f\x73\x63\162\x69\160\164\163","\x4f\x55\x31\61\x37\x33",9999);
function OU1173(){
if(!OU1141("\x6f\163\x73\x5f\x6c\x61\172\171\154\157\141\144")||!isset($_SERVER["\x48\x54\124\x50\137\x55\x53\105\122\x5f\x41\x47\x45\116\x54"])||stripos($_SERVER["\x48\x54\x54\120\x5f\125\123\x45\x52\x5f\101\107\105\116\124"],"\115\123\x49\x45"))return;
wp_enqueue_script("\x6a\x71\165\x65\x72\x79\56\x6c\x61\x7a\171\154\x6f\x61\x64",plugins_url("\57\x6c\151\142\x2f\x6c\x61\x7a\171\x6c\157\x61\144\x2e\x6a\163",__FILE__),array("\x6a\x71\x75\x65\162\x79"),false,true);
}

function OU1174(){
$post=__('Autosave remote images to OSS','oss-upload');
echo "<div class=misc-pub-section><label><input name='oss_upload_remote' type='checkbox' value='1' checked='checked' /> {$post}</label></div>";
}

function OU1175($OU1062){
global $post;
if(!current_user_can("\145\x64\x69\164\x5f\x70\x6f\x73\x74",$post->ID))return $OU1062;
$OU1017=wp_get_upload_dir();
$OU1063=substr($OU1017["\144\145\146\141\x75\154\x74"]["\x62\x61\x73\145\x75\162\154"],stripos($OU1017["\x64\x65\x66\x61\x75\x6c\x74"]["\x62\x61\x73\145\x75\x72\x6c"],"\57\57"));
$OU1064=substr($OU1017["\142\x61\x73\x65\x75\x72\154"],stripos($OU1017["\x62\x61\x73\x65\x75\162\154"],"\57\x2f"));
$OU1062=stripslashes($OU1062);
$OU1065=preg_match_all("\x2f\74\x69\x6d\x67\x2e\x2a\77\x28\x3f\x3c\x3d\x64\141\164\141\x2d\x73\x72\x63\174\144\x61\x74\x61\55\157\x72\x69\x67\x69\156\x61\154\x29\x3d\x22\x28\x2e\52\x3f\51\x22\57",$OU1062,$OU1066);
if($OU1065||preg_match_all("\x2f\x3c\x69\155\x67\x2e\x2a\77\40\x73\x72\x63\75\x22\50\x2e\x2a\77\x29\x22\x5b\x5e\76\x5d\53\76\x2f",$OU1062,$OU1066)){
@set_time_limit(0);
add_filter("\x68\164\x74\160\x5f\x72\x65\x71\165\x65\x73\x74\x5f\141\x72\x67\x73","\x4f\x55\61\x31\65\x34",11,2);
$OU1067=0;
foreach($OU1066[1]as $OU1070){
if(stripos($OU1070,"\x3a\x2f\x2f")&&!stripos($OU1070,$OU1063)&&!stripos($OU1070,$OU1064)){
if(!pathinfo($OU1070,4))$OU1070.="\43\77".OU1145($OU1070)."\x2e\x70\x6e\x67";
$OU1071=explode("\43",pathinfo($OU1070,8));
try{
$OU1072=media_sideload_image($OU1070,$post->ID,$OU1071[0],"\x69\x64");
}catch(Exception $OU1025){
$OU1072='';
}
if(!empty($OU1072)&&!is_wp_error($OU1072)){
$OU1073=get_image_tag($OU1072,$OU1071[0],0,"\x6e\x6f\156\x65","\x66\x75\154\x6c");
$OU1062=str_replace($OU1066[0][$OU1067],$OU1073,$OU1062);
}
}
$OU1067++;
}
remove_filter("\150\164\164\x70\x5f\162\145\x71\165\x65\x73\164\x5f\x61\x72\147\x73","\x4f\125\61\x31\x35\x34",11,2);
}
return $OU1062;
}

add_filter("\164\x68\x65\137\x63\x6f\x6e\164\x65\156\164","\x4f\x55\61\x31\67\66",999);
function OU1176($OU1062){
if(isset($_SERVER["\x48\124\x54\x50\137\125\x53\105\x52\x5f\x41\x47\x45\x4e\x54"])&&preg_match("\x2f\x6d\163\x69\x65\x7c\163\160\151\x64\x65\x72\174\x62\x6f\x74\x2f\151",$_SERVER["\x48\x54\124\x50\x5f\125\x53\x45\x52\x5f\101\x47\x45\x4e\x54"]))return $OU1062;
if(OU1141("\x6f\x73\x73\137\x73\x65\x72\x76\151\x63\145",10)||(!OU1146()&&!OU1141("\x6f\163\x73\137\x6c\141\x7a\x79\x6c\157\x61\x64")))return $OU1062;
return preg_replace_callback("\x2f\x3c\151\x6d\147\56\x2a\x3f\x73\x72\143\x3d\x22\x28\x5b\136\x22\x5d\53\x29\42\57",function($OU1066){
return str_replace($OU1066[1],OU1204($OU1066[1],OU1141("\x6f\x73\x73\x5f\x6c\x61\172\x79\x6c\x6f\x61\x64")),$OU1066[0]);
},$OU1062);
}

add_filter("\167\x70\137\147\x65\156\x65\x72\x61\x74\x65\137\x61\x74\164\x61\143\150\x6d\x65\x6e\x74\x5f\x6d\x65\x74\x61\x64\x61\164\x61","\x4f\125\61\61\x37\x37",9999,2);
function OU1177($OU1046,$OU1074){
if(!OU1141("\x6f\x73\x73"))return $OU1046;
if(!OU1141("\157\x73\x73\x5f\163\x65\x72\x76\x69\x63\x65",10))OU1205($OU1074,$OU1046);
if(!OU1141("\x6f\163\x73\x5f\x62\x61\143\x6b\x75\x70")){
$OU1017=wp_get_upload_dir();
$OU1006=get_attached_file($OU1074,1);
$OU1075=str_replace($OU1017["\142\141\163\x65\x64\151\162"],$OU1017["\144\x65\146\x61\165\x6c\x74"]["\x62\x61\163\x65\144\x69\x72"],$OU1006);
if(@file_exists($OU1075))@unlink($OU1075);
}
return $OU1046;
}

add_filter("\x77\160\x5f\x67\x65\x74\x5f\141\x74\x74\x61\143\150\x6d\145\x6e\164\x5f\x6d\x65\x74\x61\144\141\x74\x61","\117\x55\x31\x32\60\x30",9999,2);
function OU1200($OU1046,$OU1074){
if(!OU1141("\x6f\x73\163")||empty($OU1046["\x73\x69\x7a\145\x73"]))return $OU1046;
$OU1076=OU1141("\x6f\x73\x73\137\163\x65\x72\x76\151\x63\x65");
if($OU1076==10)return $OU1046;
if($OU1076==2||(OU1141("\x6f\x73\x73\x5f\x6c\141\x7a\171\x6c\x6f\x61\x64")&&!is_admin()))$OU1046["\x73\x69\172\x65\x73"]=array();
$OU1077=OU1141("\x6f\163\163\x5f\x73\x74\171\x6c\x65\x5f\x73\x65\160\x61\162\x61\164\x6f\x72")?trim(OU1141("\x6f\x73\x73\x5f\x73\x74\171\x6c\145\137\163\x65\160\141\162\141\x74\157\x72")):"\77\x78\x2d\x6f\x73\x73\55\160\x72\x6f\x63\145\x73\x73\x3d\163\x74\171\154\x65\57";
$OU1057=wp_check_filetype(OU1145($OU1046["\x66\x69\154\x65"]));
$OU1100=$OU1057&&$OU1057["\x65\x78\x74"]=="\x67\x69\x66"?1:0;
$OU1101=OU1141("\x6f\x73\x73\137\x71\165\141\x6c\151\x74\171")?intval(OU1141("\x6f\x73\163\x5f\161\x75\x61\154\x69\x74\171")):"\x35\60";
$OU1101=$OU1100?'':"\x2f\x71\165\x61\154\x69\x74\171\x2c\x71\x5f".$OU1101;
foreach($OU1046["\x73\x69\x7a\145\x73"]as $OU1001=>$OU1002){
if(!isset($OU1002["\146\x69\154\x65"]))continue;
$OU1102=$OU1076?"{$OU1077}{$OU1001}":"?x-oss-process=image{$OU1101}/resize,m_fill,w_{$OU1002['width']},h_{$OU1002["\150\145\x69\147\x68\x74"]}";
if($OU1100&&$OU1076&&OU1141("\x6f\x73\x73\137\x67\151\146"))$OU1102="{$OU1077}gif";
$OU1046["\x73\x69\x7a\x65\x73"][$OU1001]["\146\x69\154\x65"]=OU1145($OU1046["\x66\x69\154\x65"]).$OU1102;
}
return $OU1046;
}

add_filter("\167\x70\137\x67\x65\x74\137\141\164\164\141\x63\x68\x6d\145\x6e\164\x5f\x75\x72\x6c","\x4f\125\x31\x32\x30\x31",9999,2);
function OU1201($OU1027,$OU1074){
if(!OU1141("\x6f\x73\163")||!OU1141("\157\163\163\x5f\x75\162\x6c"))return $OU1027;
$OU1017=wp_get_upload_dir();
$OU1103=$OU1017["\x64\x65\x66\x61\x75\154\x74"]["\x62\141\x73\x65\x75\162\x6c"];
$OU1104=$OU1017["\142\x61\163\145\x75\162\x6c"];
$OU1027=OU1207(str_replace($OU1103,$OU1104,$OU1027));
if(OU1141("\157\163\163\x5f\163\x65\162\x76\151\x63\x65",10))return $OU1027;
$OU1057=wp_check_filetype(OU1145($OU1027));
if(!$OU1057||!in_array($OU1057["\145\170\x74"],array("\142\155\x70","\x67\x69\x66","\x70\156\147","\152\x70\x67","\152\160\x65","\152\x70\145\x67")))return $OU1027;
if(OU1141("\x6f\163\163\137\x73\x65\162\x76\x69\x63\x65",1)||OU1141("\x6f\x73\x73\x5f\x66\x75\x6c\154\163\x69\x7a\145\x5f\x73\x74\x79\x6c\x65")){
$OU1077=OU1141("\157\x73\x73\x5f\163\164\171\154\x65\x5f\x73\145\160\x61\162\x61\x74\x6f\162")?trim(OU1141("\x6f\x73\163\137\163\x74\x79\x6c\x65\x5f\163\x65\160\x61\x72\x61\x74\x6f\x72")):"\x3f\x78\x2d\157\x73\163\x2d\x70\162\157\143\x65\x73\x73\x3d\x73\x74\x79\x6c\x65\x2f";
$OU1105=OU1141("\157\x73\x73\x5f\x66\165\x6c\x6c\x73\x69\172\145\137\x73\x74\x79\x6c\x65")?trim(OU1141("\157\163\x73\x5f\146\x75\154\x6c\163\x69\172\145\x5f\x73\x74\x79\x6c\x65")):"\x66\x75\154\154";
$OU1027.=$OU1077.$OU1105;
if($OU1057&&$OU1057["\x65\170\164"]=="\147\151\x66"&&OU1141("\x6f\x73\163\x5f\x67\x69\x66"))return $OU1027."\137\x67\x69\x66";
}
if(!is_admin())$OU1027=OU1204($OU1027);
return $OU1027;
}

add_filter("\x67\x65\x74\x5f\141\164\x74\x61\143\x68\x65\144\137\x66\151\154\145","\x4f\x55\61\x32\x30\x32",9999,2);
function OU1202($OU1006,$OU1074){
if(OU1141("\x6f\x73\163")&&OU1141("\x6f\x73\163\x5f\x70\x61\x74\x68")){
$OU1017=wp_get_upload_dir();
$OU1103=$OU1017["\x64\145\146\141\165\x6c\x74"]["\x62\x61\x73\145\144\x69\x72"];
$OU1104=$OU1017["\x62\141\x73\x65\x64\x69\x72"];
$OU1006=str_replace($OU1103,$OU1104,$OU1006);
}
return $OU1006;
}

add_filter("\x77\x70\137\x63\x61\x6c\x63\x75\x6c\x61\x74\x65\x5f\x69\x6d\141\147\x65\x5f\x73\x72\x63\x73\x65\x74","\x4f\x55\61\62\x30\x33",9999,5);
function OU1203($OU1106,$OU1107,$OU1110,$OU1111,$OU1074){
if(!OU1141("\x6f\x73\x73")||empty($OU1111["\x73\x69\172\x65\x73"]))return $OU1106;
$OU1017=wp_get_upload_dir();
if(parse_url(admin_url(),PHP_URL_SCHEME)=="\x68\x74\x74\160\x73"){
$OU1017["\x64\x65\146\x61\x75\x6c\164"]["\x62\x61\163\145\x75\x72\154"]=set_url_scheme($OU1017["\144\x65\x66\x61\x75\x6c\x74"]["\x62\141\163\x65\x75\x72\x6c"],"\150\x74\164\x70\x73");
}
foreach($OU1106 as $OU1001=>$OU1002){
$OU1027=str_replace($OU1017["\x64\x65\x66\x61\x75\x6c\164"]["\x62\x61\x73\145\x75\162\x6c"],$OU1017["\x62\141\163\x65\x75\162\154"],$OU1106[$OU1001]["\x75\x72\x6c"]);
$OU1027=OU1207($OU1027);
if(OU1145($OU1111["\146\151\154\x65"])==wp_basename($OU1027)){
if(OU1141("\x6f\x73\x73\x5f\163\145\162\166\151\x63\145",1)||OU1141("\x6f\163\x73\x5f\x66\x75\154\154\163\151\172\x65\137\x73\164\x79\154\x65")){
$OU1077=OU1141("\157\x73\x73\x5f\x73\164\x79\x6c\x65\x5f\x73\145\x70\141\x72\x61\x74\x6f\x72")?trim(OU1141("\x6f\x73\x73\x5f\x73\x74\171\x6c\x65\x5f\x73\145\x70\x61\162\141\x74\x6f\x72")):"\x3f\x78\55\157\x73\x73\x2d\x70\x72\x6f\143\x65\x73\163\x3d\163\164\x79\x6c\x65\x2f";
$OU1105=OU1141("\157\163\x73\x5f\x66\165\154\154\x73\x69\172\x65\x5f\163\164\x79\x6c\x65")?trim(OU1141("\x6f\x73\x73\x5f\x66\165\154\x6c\x73\x69\x7a\x65\137\163\x74\x79\x6c\x65")):"\x66\165\x6c\x6c";
$OU1027.=$OU1077.$OU1105;
}
}
$OU1106[$OU1001]["\165\x72\x6c"]=OU1204($OU1027);
}
return $OU1106;
}

function OU1204($OU1070,$OU1112=false){
if(!OU1141("\157\163\x73")||OU1141("\x6f\x73\x73\x5f\163\145\x72\x76\151\x63\145",10))return $OU1070;
if(isset($_SERVER["\110\x54\x54\x50\x5f\x55\x53\x45\x52\137\101\x47\105\116\x54"])&&preg_match("\x2f\x73\x70\151\144\x65\162\x7c\x62\157\164\57\x69",$_SERVER["\x48\x54\124\120\x5f\125\x53\x45\x52\x5f\101\x47\x45\x4e\124"]))return $OU1070;
$OU1017=wp_get_upload_dir();
$OU1063=substr($OU1017["\144\x65\x66\x61\x75\154\164"]["\142\x61\x73\145\x75\162\154"],stripos($OU1017["\x64\x65\146\141\x75\x6c\x74"]["\142\x61\x73\x65\165\x72\154"],"\x2f\57"));
$OU1064=substr($OU1017["\x62\141\x73\x65\x75\x72\x6c"],stripos($OU1017["\142\x61\163\x65\x75\x72\154"],"\x2f\57"));
$OU1070=str_replace($OU1063,$OU1064,$OU1070);
if(empty($OU1070)||stripos($OU1070,$OU1064)===false)return $OU1070;
$OU1113=$OU1114=$OU1115='';
if(stripos($OU1070,"\x23"))$OU1070=substr($OU1070,0,strripos($OU1070,"\x23"));
if((OU1141("\157\163\163\x5f\144\x65\x66\x61\x75\x6c\164\x5f\x73\x74\x79\154\145")&&($OU1115=stripos($OU1070,trim(OU1141("\157\x73\x73\x5f\x64\x65\x66\x61\x75\154\x74\137\163\x74\171\x6c\x65")))))
||(OU1141("\x6f\163\163\137\163\x74\x79\154\145\137\x73\x65\x70\x61\162\141\x74\x6f\x72")&&($OU1115=stripos($OU1070,trim(OU1141("\x6f\x73\163\137\x73\x74\x79\x6c\145\137\x73\x65\160\141\162\x61\164\157\x72")))))
||($OU1115=stripos($OU1070,"\x3f\x78\55\x6f\x73\163\55\160\x72\157\x63\x65\x73\x73\x3d\163\x74\171\x6c\x65\57"))){
$OU1113="\137\167\145\x62\x70";
}else if($OU1115=stripos($OU1070,"\x3f\170\55\157\x73\163\x2d\x70\x72\x6f\x63\x65\163\x73\75\x69\x6d\x61\147\x65\x2f")){
$OU1113="\x2f\x66\157\162\x6d\141\x74\54\167\145\142\x70";
}else if(!stripos($OU1070,"\77")){
$OU1113="\x3f\x78\x2d\157\x73\x73\x2d\160\x72\157\x63\x65\163\x73\75\x69\x6d\141\x67\x65\x2f\x66\157\x72\x6d\x61\x74\x2c\x77\x65\x62\x70";
}
if($OU1112&&!is_feed()&&!wp_doing_ajax()){
$OU1114=empty($OU1115)?$OU1070:substr($OU1070,0,$OU1115);
if($OU1116=OU1141("\x6f\163\x73\x5f\x6c\141\x7a\x79\x75\x72\154")){
$OU1114=str_replace("\173\111\115\x47\175",$OU1114,$OU1116);
}else{
$OU1114.="\x3f\170\55\157\x73\163\x2d\x70\x72\x6f\x63\x65\x73\163\x3d\x69\155\141\x67\145\57\161\x75\x61\154\x69\164\x79\x2c\161\x5f\x31\x30\x2f\x72\x65\163\x69\172\145\54\x6d\x5f\154\x66\x69\164\x2c\x77\x5f\x32\60";
if(OU1146())$OU1114.="\x2f\x66\x6f\x72\x6d\x61\x74\x2c\167\145\142\160";
}
}
if(OU1146()&&!empty($OU1113)&&!stripos($OU1070,$OU1113))$OU1070.=$OU1113;
return empty($OU1114)?$OU1070:$OU1114."\x22\x20\x64\x61\x74\x61\55\x73\x72\143\x3d\x22".$OU1070;
}

function OU1205($OU1074,$OU1046=array()){
$OU1052=array();
$OU1017=wp_get_upload_dir();
if(empty($OU1046))$OU1046=wp_get_attachment_metadata($OU1074,1);
if(empty($OU1046)||empty($OU1046["\163\151\172\145\163"]))return $OU1052;
foreach($OU1046["\x73\x69\x7a\145\x73"]as $OU1001=>$OU1002){
if(empty($OU1002["\146\151\154\x65"]))continue;
if(OU1145($OU1046["\146\151\154\x65"])==OU1145($OU1002["\x66\x69\x6c\145"]))continue;
$OU1006=$OU1017["\142\x61\x73\x65\x64\x69\162"]."\x2f".dirname($OU1046["\x66\x69\x6c\x65"])."\x2f".OU1145($OU1002["\x66\151\x6c\145"]);
if(@file_exists($OU1006)&&@unlink($OU1006))$OU1052[]=$OU1006;
if(!empty($OU1017["\144\x65\146\x61\x75\x6c\164"])){
$OU1006=$OU1017["\x64\x65\x66\x61\x75\x6c\x74"]["\x62\141\163\x65\144\x69\x72"]."\x2f".dirname($OU1046["\x66\x69\x6c\x65"])."\57".OU1145($OU1002["\146\x69\154\x65"]);
if(@file_exists($OU1006)&&@unlink($OU1006))$OU1052[]=$OU1006;
}
}
return $OU1052;
}

add_action("\x64\145\x6c\145\164\x65\137\x61\x74\164\x61\143\x68\x6d\145\156\164","\117\x55\x31\x32\x30\x36");
function OU1206($OU1074){
if(!OU1141("\x6f\x73\x73"))return;
$OU1052=array();
$OU1017=wp_get_upload_dir();
if($OU1006=get_post_meta($OU1074,"\137\x77\x70\x5f\x61\x74\x74\141\x63\x68\145\144\x5f\x66\x69\154\x65",true)){
$OU1006=str_replace($OU1017["\144\x65\x66\x61\165\x6c\x74"]["\x62\x61\163\145\144\x69\x72"]."\x2f",'',$OU1006);
$OU1052[]=$OU1017["\142\x61\163\145\144\151\162"]."\x2f".$OU1006;
$OU1052[]=$OU1017["\x64\145\x66\x61\165\x6c\164"]["\142\141\x73\x65\x64\151\162"]."\x2f".$OU1006;
$OU1117=dirname($OU1006);
$OU1006=get_post_meta($OU1074,"\x5f\x77\160\x5f\x61\x74\x74\x61\143\x68\155\145\156\x74\x5f\x62\141\x63\x6b\165\x70\x5f\163\x69\172\145\163",true);
if(!empty($OU1006)){
foreach($OU1006 as $OU1001=>$OU1002){
$OU1052[]=$OU1017["\142\x61\x73\x65\x64\x69\x72"]."\57".$OU1117."\57".OU1145($OU1002["\x66\x69\154\x65"]);
$OU1052[]=$OU1017["\x64\x65\x66\141\x75\x6c\x74"]["\x62\x61\x73\x65\x64\x69\x72"]."\x2f".$OU1117."\x2f".OU1145($OU1002["\x66\151\154\x65"]);
}
}
}
if(!empty($OU1052))$OU1052=array_unique($OU1052);
foreach($OU1052 as $OU1001){if(@file_exists($OU1001))@unlink($OU1001);}
OU1205($OU1074);
}

function OU1207($OU1027){
if($OU1103=trim(OU1141("\x6f\163\x73\137\165\x72\x6c\x5f\x66\151\x6e\144"))){
$OU1103=preg_split('/\|\|/',$OU1103);
$OU1104=preg_split('/\|\|/',trim(OU1141("\x6f\x73\x73\x5f\x75\162\x6c\137\x72\x65\160\x6c\141\x63\145")));
$OU1027=str_replace($OU1103,$OU1104,$OU1027);
}
return $OU1027;
}

add_filter("\x77\160\137\151\x6d\141\x67\145\x5f\x65\x64\x69\x74\x6f\162\163","\117\125\61\62\x31\60");
function OU1210($OU1052){
return OU1141("\x6f\x73\x73")?array("\x57\x50\x5f\x49\x6d\x61\x67\x65\137\x45\x64\x69\x74\x6f\162\x5f\x47\x44","\x57\x50\137\111\x6d\141\x67\x65\x5f\105\x64\x69\x74\157\x72\x5f\x49\x6d\141\147\x69\x63\x6b"):$OU1052;
}

add_filter("\x66\141\154\x6c\x62\141\x63\153\x5f\x69\156\x74\x65\162\x6d\x65\x64\x69\x61\164\x65\x5f\x69\155\x61\x67\145\x5f\x73\x69\x7a\145\x73","\x4f\x55\x31\x32\x31\61",10,2);
function OU1211($OU1120,$OU1121){
return OU1141("\x6f\x73\x73")?array():$OU1120;
}

add_filter("\x75\x70\154\x6f\141\x64\137\155\x69\x6d\145\163","\117\x55\x31\x32\x31\x32",99);
function OU1212($OU1122){
if($OU1052=trim(OU1141("\x75\x70\154\x6f\x61\144\x5f\x6d\x69\x6d\x65\x73"))){
$OU1052=explode("\x2c",$OU1052);
foreach($OU1052 as $OU1001){
$OU1123=explode("\75",trim($OU1001));
if(count($OU1123)==2)$OU1122[trim($OU1123[0])]=trim($OU1123[1]);
}
}
return $OU1122;
}

add_action("\143\x75\x72\162\x65\x6e\164\137\x73\x63\x72\x65\x65\x6e","\117\x55\x31\x32\x31\63");
function OU1213(){
$OU1124=get_current_screen();
if($OU1124->id!="\163\145\164\x74\x69\x6e\147\163\x5f\x70\141\x67\x65\x5f\x6f\x73\x73\55\165\x70\154\x6f\x61\x64"||!OU1141("\x6f\x73\163"))return;
$OU1125="\x3c\x73\x74\x79\x6c\x65\76\x2e\155\145\x74\x61\x62\157\x78\x2d\160\x72\x65\x66\163\x20\x73\160\x61\x6e\40\173\144\151\x73\x70\154\x61\171\x3a\40\151\x6e\x6c\x69\x6e\x65\x2d\x62\x6c\157\x63\x6b\x3b\40\x76\x65\162\164\151\x63\x61\x6c\x2d\x61\154\x69\x67\x6e\x3a\x20\x74\x65\170\x74\x2d\x62\x6f\164\164\x6f\x6d\73\x20\x6d\141\162\147\x69\x6e\x3a\x20\x31\x70\x78\x20\x30\40\60\40\x32\x70\x78\73\x20\x70\141\x64\144\151\156\x67\x3a\x20\x30\40\x35\x70\170\x3b\40\x62\157\x72\x64\145\162\x2d\162\x61\x64\x69\x75\x73\x3a\x20\65\x70\170\73\x20\x62\x61\x63\x6b\x67\162\x6f\x75\x6e\144\55\x63\x6f\154\x6f\x72\x3a\x20\43\x63\141\x34\x61\61\146\x3b\x20\x63\x6f\154\x6f\162\x3a\x20\x23\x66\146\x66\73\x20\x66\157\x6e\x74\x2d\163\x69\x7a\x65\x3a\40\x31\x30\x70\x78\73\x20\x6c\151\x6e\x65\x2d\x68\x65\151\x67\150\x74\72\40\x31\x37\x70\170\x3b\x7d\x3c\57\x73\x74\x79\x6c\145\76";
$OU1126="\x3c\x70\76".OU1167("\104\x65\x73\x63\x72\x69\160\x74\x69\x6f\x6e")."\74\x2f\x70\x3e\x3c\x62\x72\57\x3e\x3c\x70\76".
OU1172("\57\57\160\162\x6f\x6d\x6f\x74\151\157\x6e\x2e\x61\x6c\x69\171\x75\x6e\x2e\143\x6f\155\57\156\x74\x6d\163\57\x79\165\156\160\x61\162\x74\145\x72\x2f\x69\x6e\x76\x69\x74\x65\x2e\x68\x74\155\x6c\x3f\x75\x73\145\x72\x43\x6f\144\x65\x3d\71\165\x66\x63\x75\151\x75\x66\x26\x75\164\x6d\x5f\x73\x6f\x75\x72\143\x65\x3d\71\165\x66\143\x75\x69\165\x66",__('Aliyun Coupon <span>NEW</span>','oss-upload'),"\x62\165\x74\x74\x6f\156\x2c\x62\x6c\x61\x6e\153").
OU1172("\x2f\x2f\160\x72\x6f\x6d\x6f\x74\151\x6f\x6e\x2e\141\x6c\x69\x79\x75\x6e\x2e\143\x6f\x6d\57\x6e\164\155\x73\57\x61\143\x74\x2f\157\x73\x73\55\x64\x69\163\x63\x6f\x75\x6e\x74\x2e\x68\x74\155\x6c\x3f\x75\163\145\x72\x43\x6f\x64\x65\75\x39\x75\146\x63\x75\x69\x75\x66\x26\x75\x74\x6d\x5f\x73\x6f\165\x72\x63\x65\x3d\x39\165\x66\x63\x75\x69\x75\146",__('OSS Discount <span>HOT</span>','oss-upload'),"\x62\165\164\x74\x6f\156\54\x62\x6c\x61\x6e\153").
OU1172("\x2f\57\x77\x6f\x72\x64\x70\x72\145\x73\x73\56\x6f\162\147\x2f\163\x75\x70\160\157\x72\x74\x2f\x70\x6c\x75\x67\x69\x6e\x2f\157\163\x73\55\x75\x70\x6c\x6f\x61\x64\x2f\x72\x65\x76\151\145\x77\x73\57",__('Plugin Rating','oss-upload'),"\x62\x75\164\164\x6f\x6e\x2c\x62\x6c\x61\x6e\x6b").
OU1172(OU1167("\x50\x6c\x75\x67\x69\x6e\x55\122\x49"),__('Support and Help','oss-upload'),"\x62\x75\x74\164\x6f\x6e\54\x62\154\x61\x6e\153").
OU1172("\x2f\57\x77\x77\x77\56\170\x69\x61\x6f\x6d\x61\x63\x2e\x63\x6f\155\x2f\x61\x62\x6f\165\164",__('Contact Me','oss-upload'),"\142\x75\x74\x74\157\x6e\x2c\x62\154\x61\x6e\x6b").
OU1172("\x2f\x2f\x77\x77\x77\x2e\170\x69\141\x6f\x6d\141\x63\x2e\x63\x6f\155\x2f\x74\141\147\x2f\x77\x6f\x72\x6b",__('See More Plugins','oss-upload'),"\142\x75\x74\x74\x6f\x6e\54\x62\x6c\x61\156\x6b")."\x3c\57\160\x3e";
$OU1127=$OU1125."\x3c\x70\x3e\x3c\163\164\x72\x6f\156\x67\x3e".__('For more information','oss-upload')."\x3c\57\x73\164\x72\x6f\x6e\x67\x3e\x3c\x2f\x70\76".
OU1172("\x2f\x2f\x77\167\x77\x2e\x61\x6c\151\171\x75\x6e\x2e\x63\x6f\x6d\57\160\x72\157\x64\x75\x63\x74\x2f\157\163\x73\x2f",__('Aliyun OSS','oss-upload'),"\160\x2c\x62\154\x61\x6e\153").
OU1172("\x2f\x2f\157\x73\x73\x2e\x63\x6f\x6e\x73\x6f\x6c\x65\x2e\x61\154\x69\171\x75\156\x2e\143\x6f\155\x2f\x69\156\144\145\x78",__('OSS Console','oss-upload'),"\x70\x2c\x62\154\x61\156\x6b").
OU1172("\x2f\x2f\x68\x65\154\x70\x2e\141\x6c\x69\x79\165\x6e\x2e\x63\x6f\x6d\x2f\x64\157\143\x75\x6d\145\156\x74\137\x64\x65\164\x61\151\154\x2f\x33\x32\x31\x37\x34\x2e\x68\x74\155\x6c",__('OSS PHP SDK','oss-upload'),"\x70\54\x62\x6c\x61\x6e\x6b");
$OU1124->add_help_tab(array("\x69\x64"=>"\x6f\163\x73\137\x75\x70\x6c\x6f\x61\x64\x5f\x68\145\x6c\x70","\164\151\x74\154\145"=>__('About','oss-upload'),"\x63\x6f\x6e\x74\145\x6e\164"=>$OU1126));
$OU1124->set_help_sidebar($OU1127);
}

add_action("\141\x64\x6d\151\156\x5f\156\x6f\x74\x69\x63\x65\x73","\x4f\x55\61\x32\x31\x34");
function OU1214(){
if(isset($_GET["\x73\x65\x74\164\x69\x6e\x67\x73\x2d\x75\x70\x64\x61\164\x65\x64"])){
if(!is_super_admin()||!OU1141("\x6f\x73\x73"))return;
@set_time_limit(0);
$OU1130=false;
$OU1131=1;
if($_GET["\x73\x65\x74\x74\151\x6e\x67\x73\x2d\x75\160\x64\x61\x74\x65\x64"]=="\143\x6c\145\x61\x6e"){
$OU1017=wp_get_upload_dir();
try{
$OU1055=__('Starting...','oss-upload')."<br/>\n";
$OU1013=get_posts(array("\x70\x6f\x73\x74\137\x74\x79\x70\x65"=>"\x61\x74\164\141\143\x68\155\145\x6e\x74","\160\157\163\164\163\137\x70\x65\x72\x5f\x70\x61\x67\x65"=>-1));
$OU1132=array();
foreach($OU1013 as $OU1006){
$OU1022=pathinfo(get_attached_file($OU1006->ID),1);
if(!in_array($OU1022,$OU1132))$OU1132[]=$OU1022;
if(isset($_GET["\146\x6f\162\x63\145"])){
$OU1022=pathinfo(get_attached_file($OU1006->ID,1),1);
if(!in_array($OU1022,$OU1132))$OU1132[]=$OU1022;
}
if($OU1052=OU1205($OU1006->ID)){
foreach($OU1052 as $OU1002){
$OU1055.=$OU1131++.". {$OU1002} deleted<br/>\n";
}
}
}
foreach($OU1132 as $OU1022){
$OU1133=OU1150($OU1022);
foreach($OU1133 as $OU1070){
if(preg_match('/\-[0-9]+x[0-9]+\./',$OU1070)&&file_is_valid_image($OU1070)){
if(@file_exists($OU1070)&&@unlink($OU1070)){
$OU1055.=$OU1131++.". {$OU1070} deleted<br/>\n";
}
}
}
}
if($OU1131==1){
$OU1055=__('No thumbnail found','oss-upload');
}else{
$OU1055.=__('Clean thumbnails done','oss-upload');
$OU1130=true;
}
}catch(Exception $OU1025){
$OU1055=$OU1025->getMessage();
}
}else if($_GET["\x73\x65\x74\x74\x69\x6e\x67\163\x2d\165\160\x64\x61\x74\145\x64"]=="\x75\x70\x6c\157\x61\x64"){
$OU1017=wp_get_upload_dir();
$OU1010=explode("\x2f",substr($OU1017["\x62\141\163\145\x64\x69\x72"]."\x2f",6),2);
try{
$OU1055=__('Starting...','oss-upload')."<br/>\n";
$OU1023=new OU_ALIOSS;
$OU1055.=$OU1023->create_mtu_object_by_dir($OU1010[0],$OU1017["\x64\145\x66\x61\x75\154\164"]["\x62\x61\x73\145\144\x69\162"],true);
$OU1055.=__('Upload local storage to OSS done','oss-upload');
$OU1130=true;
}catch(Exception $OU1025){
$OU1055=$OU1025->getMessage();
}
}else if($_GET["\x73\x65\164\164\x69\156\x67\x73\x2d\x75\x70\144\x61\x74\x65\x64"]=="\163\x79\x6e\x63"){
$OU1013=get_posts(array("\x70\x6f\x73\x74\x5f\164\x79\160\x65"=>"\x61\x74\x74\x61\x63\x68\x6d\x65\x6e\164","\x70\x6f\x73\x74\163\x5f\x70\x65\x72\x5f\x70\x61\x67\145"=>-1));
$OU1017=wp_get_upload_dir();
$OU1055=__('Starting...','oss-upload')."<br/>\n";
foreach($OU1013 as $OU1006){
$OU1134=get_attached_file($OU1006->ID);
$OU1075=str_replace($OU1017["\x62\141\x73\x65\x64\151\x72"],$OU1017["\144\145\x66\x61\165\x6c\164"]["\x62\141\x73\x65\x64\x69\162"],$OU1134);
if(@file_exists($OU1075)&&!@file_exists($OU1134)&&($OU1135=OU1153($OU1075))){
$OU1055.=$OU1131++.". {$OU1135} synced<br/>\n";
}
}
if($OU1131==1){
$OU1055=__('No attachments need to be synced','oss-upload');
}else{
$OU1055.=__('Sync missing attachments to OSS done','oss-upload');
$OU1130=true;
}
}else if($_GET["\163\x65\164\x74\x69\156\x67\x73\55\x75\x70\x64\141\164\x65\x64"]=="\x72\x65\163\x65\164"){
@ini_set("\155\145\155\x6f\162\x79\137\x6c\151\x6d\x69\x74","\x32\60\x34\70\x4d");
$OU1013=get_posts(array("\160\x6f\163\x74\x5f\164\x79\160\x65"=>"\141\164\164\x61\143\x68\x6d\145\156\x74","\x70\x6f\x73\x74\x73\x5f\x70\145\x72\x5f\x70\x61\x67\145"=>-1));
$OU1055=__('Starting...','oss-upload')."<br/>\n";
foreach($OU1013 as $OU1006){
if(!wp_attachment_is_image($OU1006->ID))continue;
$OU1070=get_attached_file($OU1006->ID);
$OU1121=wp_generate_attachment_metadata($OU1006->ID,$OU1070);
wp_update_attachment_metadata($OU1006->ID,$OU1121);
$OU1055.=$OU1131++.". {$OU1006->ID} {$OU1070} reset<br/>\n";
}
$OU1055.=__('Reset attachments metadata done','oss-upload');
$OU1130=true;
}else if($_GET["\x73\145\x74\x74\x69\x6e\147\x73\55\x75\160\x64\x61\x74\x65\144"]=="\x74\145\x73\x74"){
try{
$OU1136=md5(time());
$OU1006=OU1141("\x6f\163\x73\137\x70\141\x74\x68")."\x2f\x6f\x73\163\137\x75\x70\154\157\x61\144\x5f".$OU1136."\56\x74\x78\164";
$OU1137=file_put_contents($OU1006,$OU1136);
if($OU1137==strlen($OU1136)){
$OU1055=__('Write OK, ','oss-upload');
$OU1137=file_get_contents($OU1006);
if($OU1137==$OU1136){
$OU1055.=__('Read OK, ','oss-upload');
$OU1137=unlink($OU1006);
if($OU1137===true){
$OU1055.=__('Delete OK','oss-upload');
$OU1130=true;
}else{
throw new RequestCore_Exception($OU1055.__('Delete Error: ','oss-upload').$OU1137);
}
}else{
throw new RequestCore_Exception($OU1055.__('Read Error: ','oss-upload').$OU1137);
}
}else{
throw new RequestCore_Exception($OU1055.__('Write Error: ','oss-upload').$OU1137);
}
}catch(Exception $OU1025){
$OU1055=esc_html($OU1025->message);
}
}
if(isset($OU1055))echo "\x3c\x64\151\166\40\143\x6c\141\x73\x73\x3d\42".($OU1130?"\165\160\144\x61\x74\145\x64\40\x66\141\x64\x65":"\x65\162\x72\x6f\162")."\42\x3e\74\x70\x3e".$OU1055."\74\x2f\x70\x3e\x3c\x2f\x64\x69\166\76";
}
if(isset($_SESSION["\157\x73\x73\x5f\x75\x70\x6c\157\x61\144\x5f\x65\x72\162\x6f\x72"])){
echo "\x3c\144\x69\x76\x20\143\x6c\141\x73\x73\75\42\145\x72\x72\x6f\x72\x22\x3e\x3c\160\x3e".$_SESSION["\157\163\x73\137\x75\160\x6c\x6f\x61\144\x5f\x65\162\x72\x6f\x72"]."\74\57\x70\x3e\x3c\x2f\x64\151\x76\x3e";
}
}

function OU1215(){?>
    <div class="wrap">
        <h1><?php _e('OSS Upload','oss-upload')?>
            <a class="page-title-action" href="<?php echo OU1167("\x50\154\x75\x67\151\x6e\x55\122\x49");?>" target="_blank"><?php echo OU1167("\x56\x65\x72\x73\151\x6f\x6e");?></a>
        </h1>
        <form action="options.php" method="post">
        <?php settings_fields("\x6f\163\163\x5f\165\x70\x6c\x6f\141\144\x5f\x61\x64\x6d\x69\x6e\137\x6f\x70\164\x69\x6f\x6e\x73\137\147\x72\157\x75\x70");?>
        <table class="form-table">
        <tr valign="top">
        <th scope="row"><?php _e('Enable','oss-upload')?></th>
        <td>
            <label><input name="ouop[oss]" type="checkbox" value="1" <?php checked(OU1141("\x6f\163\163"),1);?> />
            <?php _e('Use OSS as media library storage','oss-upload')?></label>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Access Key','oss-upload')?></th>
        <td>
            <input name="ouop[oss_akey]" size="60" placeholder="Access Key" value="<?php echo OU1141("\x6f\x73\x73\137\x61\x6b\x65\171")?>" required />
            <?php echo OU1172("\x2f\x2f\x61\x6b\x2d\x63\157\156\x73\x6f\x6c\x65\x2e\x61\x6c\x69\x79\x75\156\x2e\143\x6f\x6d\57","\x3f","\142\x6c\141\156\153");?>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Secret Key','oss-upload')?></th>
        <td>
            <input type="password" name="ouop[oss_skey]" size="60" placeholder="Secret Key" value="<?php echo OU1141("\x6f\x73\x73\x5f\x73\x6b\145\x79")?>" required />
            <?php echo OU1172("\x2f\x2f\x61\x6b\55\x63\x6f\x6e\x73\157\x6c\x65\56\141\154\x69\x79\x75\x6e\x2e\x63\x6f\155\x2f","\x3f","\x62\154\x61\156\x6b");?>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Upload Path','oss-upload')?></th>
        <td>
            <input name="ouop[oss_path]" size="60" placeholder="oss://{BUCKET}/{PATH}" value="<?php echo rtrim(OU1141("\x6f\x73\x73\x5f\160\x61\x74\x68"),"\57");?>" required />
            <?php echo OU1172("\57\x2f\x68\x65\x6c\160\x2e\x61\x6c\151\x79\165\x6e\x2e\x63\157\155\57\144\x6f\143\x75\x6d\x65\x6e\x74\x5f\x64\x65\x74\x61\x69\x6c\x2f\x33\x31\x39\60\x32\56\x68\x74\x6d\x6c","\x3f","\142\x6c\x61\x6e\x6b");?>
            <p <?php OU1170("\x6f\x73\x73\137\165\160\x6c\157\141\144\137\x64\x65\x73\x63");?>><small><?php _e('<code>{BUCKET}</code> is Bucket name, <code>{PATH}</code> can be empty, with no slash at the end','oss-upload')?></small></p>
            <div <?php OU1170("\x6f\x73\x73\137\165\x70\x6c\x6f\x61\144\x5f\145\x78\x61\x6d\x70\x6c\x65");?>>
            <p><small><code>oss://my-bucket</code></small></p>
            <p><small><code>oss://my-bucket/uploads</code></small></p>
            </div>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Visit URL','oss-upload')?></th>
        <td>
            <input name="ouop[oss_url]" type="url" size="60" placeholder="http://oss.aliyuncs.com/{BUCKET}/{PATH}" value="<?php echo rtrim(OU1141("\x6f\x73\163\137\165\162\x6c"),"\x2f");?>" required />
            <?php echo OU1172("\57\57\x68\x65\154\160\x2e\141\x6c\x69\x79\165\x6e\x2e\x63\x6f\x6d\x2f\x64\x6f\x63\x75\x6d\x65\x6e\164\137\x64\x65\164\x61\x69\x6c\x2f\x33\x31\x39\x30\x32\x2e\150\x74\x6d\x6c","\77","\x62\154\x61\156\x6b");?>
            <p <?php OU1170("\x6f\x73\x73\137\165\160\154\x6f\x61\x64\137\x64\x65\163\x63");?>><small><?php _e('<code>{BUCKET}</code> can be directory or domain, <code>{PATH}</code> can be empty','oss-upload')?></small></p>
            <div <?php OU1170("\x6f\x73\163\137\165\x70\x6c\x6f\x61\144\x5f\x65\x78\x61\155\x70\x6c\x65");?>>
            <p><small><code>http://my-bucket.oss-cn-shenzhen.aliyuncs.com</code></small></p>
            <p><small><code>http://my-bucket.oss-cn-shenzhen.aliyuncs.com/uploads</code></small></p>
            <p><small><code>http://www.my-oss-domain.com</code></small></p>
            <p><small><code>https://www.my-oss-domain.com/uploads</code></small></p>
            <p><small><code>https://img.my-oss-domain.com</code></small></p>
            </div>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Upload EndPoint','oss-upload')?></th>
        <td>
            <input name="ouop[oss_endpoint]" size="60" placeholder="oss-cn-hangzhou.aliyuncs.com" value="<?php echo OU1141("\x6f\x73\163\137\x65\x6e\x64\x70\157\151\x6e\x74")?>" required />
            <?php echo OU1172("\x2f\x2f\x68\x65\154\x70\56\x61\x6c\x69\x79\165\156\56\x63\157\x6d\57\x64\157\x63\165\155\145\x6e\x74\137\144\x65\x74\x61\151\x6c\x2f\63\61\70\x33\x37\x2e\x68\x74\155\154","\x3f","\142\x6c\x61\156\x6b");?>
            <p <?php OU1170("\x6f\163\x73\x5f\x75\160\154\157\x61\x64\x5f\x64\x65\163\x63");?>><small><?php _e('Endpoint of your Bucket, can be internal address if WEB SERVER is in the same area with OSS','oss-upload')?></small></p>
            <div <?php OU1170("\157\163\x73\137\x75\x70\154\x6f\x61\144\x5f\145\170\141\155\x70\x6c\x65");?>>
            <p><small><code>oss-cn-hangzhou.aliyuncs.com</code></small></p>
            <p><small><code>oss-cn-shenzhen.aliyuncs.com</code></small></p>
            <p><small><code>oss-cn-shanghai.aliyuncs.com</code></small></p>
            <p><small><code>oss-us-west-1.aliyuncs.com</code></small></p>
            <p><small><code>oss-cn-hangzhou-internal.aliyuncs.com</code></small></p>
            </div>
        </td></tr>
        <tr valign="top">
        <th scope="row"></th>
        <td>
            <?php 
if(OU1141("\x6f\163\163")&&OU1141("\x6f\x73\x73\x5f\x61\153\145\x79")&&OU1141("\x6f\x73\x73\137\163\x6b\x65\x79")&&OU1141("\x6f\x73\x73\137\145\x6e\x64\160\x6f\x69\x6e\x74")){
echo OU1172("\157\x70\x74\151\157\x6e\x73\55\147\145\x6e\145\162\x61\x6c\x2e\x70\x68\160\x3f\x70\141\147\145\x3d\x6f\x73\x73\x2d\x75\x70\x6c\x6f\141\x64\x26\x73\145\x74\164\x69\156\x67\x73\55\165\160\144\141\164\x65\x64\75\x74\x65\x73\x74",__('Run a test','oss-upload'),"\x70\x2c\142\x75\x74\x74\157\x6e");
}?>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Image Thumbnails','oss-upload')?></th>
        <td>
            <p><label><input name="ouop[oss_service]" type="radio" value="0" <?php checked(OU1141("\x6f\x73\163\x5f\x73\145\162\x76\151\x63\x65"),0);?> /> <?php _e('Use Image Service via Parameter, default and simple','oss-upload')?></label>
            <?php echo OU1172("\x2f\57\x68\145\154\x70\x2e\x61\x6c\x69\171\x75\156\x2e\143\x6f\x6d\57\x64\x6f\x63\x75\x6d\x65\x6e\x74\x5f\x64\x65\x74\x61\x69\x6c\57\64\x34\66\70\70\x2e\150\164\x6d\x6c","\77","\x62\154\x61\x6e\x6b");?></p>
            <p <?php OU1170("\157\163\163\137\165\160\x6c\x6f\x61\x64\x5f\x65\x78\x61\x6d\160\154\x65");?>><small><code>photo.jpg?x-oss-process=image/quality,q_<?php echo OU1141("\x6f\x73\x73\137\161\x75\x61\154\151\x74\x79")?intval(OU1141("\157\x73\x73\x5f\161\x75\x61\x6c\x69\164\171")):"\65\x30";?>/resize,m_fill,w_{width},h_{height}</code></small></p><br/>
            <p><label><input name="ouop[oss_service]" type="radio" value="1" <?php checked(OU1141("\x6f\x73\x73\x5f\x73\x65\x72\x76\x69\x63\x65"),1);?> /> <?php _e('Use Image Service via Style, powerful but require styles setting on OSS','oss-upload')?></label>
            <?php echo OU1172("\57\x2f\x68\145\154\x70\56\x61\x6c\x69\x79\x75\x6e\x2e\143\x6f\155\x2f\x64\157\x63\x75\155\x65\156\164\x5f\x64\x65\x74\x61\x69\x6c\x2f\x34\x34\x36\x38\67\x2e\x68\x74\155\154","\x3f","\142\x6c\x61\x6e\x6b");?></p>
            <p <?php OU1170("\x6f\x73\x73\x5f\x75\x70\x6c\x6f\x61\x64\x5f\145\x78\141\x6d\x70\x6c\x65");?>><small><code>photo.jpg<?php echo OU1141("\157\163\x73\x5f\163\164\x79\154\x65\137\x73\x65\x70\x61\x72\141\x74\157\162")?trim(OU1141("\157\163\163\137\x73\x74\x79\x6c\x65\137\x73\x65\x70\x61\x72\141\x74\157\x72")):"\x3f\x78\55\x6f\x73\x73\x2d\160\x72\x6f\x63\145\x73\x73\x3d\x73\164\171\154\145\x2f";?>{style}</code>:
            <?php foreach(get_intermediate_image_sizes()as $OU1002){echo "\x3c\x63\157\144\x65\x3e".$OU1002."\74\x2f\143\x6f\x64\x65\x3e\x20";}?>
            </small></p><br/>
            <p><label><input name="ouop[oss_service]" type="radio" value="10" <?php checked(OU1141("\157\x73\x73\x5f\163\x65\x72\166\x69\143\x65"),10);?> /> <?php _e('Use physical thumbnails, check this when having problem with theme','oss-upload')?></label></p>
            <p <?php OU1170("\157\163\163\x5f\165\160\x6c\x6f\141\144\x5f\x65\170\x61\x6d\x70\x6c\145");?>><small><code>photo-{width}x{height}.jpg</code></small></p><br/>
            <p><label><input name="ouop[oss_service]" type="radio" value="2" <?php checked(OU1141("\157\163\x73\137\x73\145\x72\x76\x69\x63\x65"),2);?> /> <?php _e('Disable image thumbnails','oss-upload')?></label></p>
            <p <?php OU1170("\157\x73\x73\x5f\x75\x70\154\x6f\x61\x64\x5f\145\170\x61\x6d\x70\x6c\x65");?>><small><code>photo.jpg</code></small></p><br/>
            <p><?php 
echo OU1172("\157\160\x74\151\157\x6e\x73\x2d\x6d\x65\x64\x69\x61\x2e\x70\x68\x70",__('Media Sizes Options','oss-upload'),"\142\x75\164\x74\x6f\x6e");
echo OU1172("\x3f\x70\x61\x67\x65\x3d\x6f\163\x73\55\x75\x70\x6c\157\x61\x64\46\x73\x65\x74\x74\151\156\x67\x73\55\165\x70\144\141\x74\x65\x64\75\143\154\x65\x61\x6e",__('Clean Thumbnails','oss-upload'),"\x62\x75\x74\164\157\x6e");
if(!OU1141("\x6f\x73\x73\137\163\x65\x72\x76\151\x63\x65",2))echo OU1172("\x3f\x70\x61\x67\x65\x3d\157\163\x73\x2d\x75\160\x6c\x6f\x61\144\x26\163\x65\x74\164\x69\x6e\147\x73\55\x75\x70\x64\x61\x74\x65\x64\x3d\162\x65\163\x65\164",__('Regenerate Thumbnails','oss-upload'),"\x62\165\164\164\157\x6e");
?></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Thumbnail Quality','oss-upload')?></th>
        <td>
            <p><label><input type="number" name="ouop[oss_quality]" size="10" min="1" max="99" value="<?php echo OU1141("\x6f\x73\163\137\x71\x75\x61\154\x69\164\x79")?>" /></label></p>
            <p <?php OU1170("\157\x73\163\x5f\x75\x70\x6c\x6f\x61\144\x5f\144\x65\163\x63");?>><small><?php _e('Set the quality of thumbnail for OSS Image Servie to speed up image loading, the smaller the faster','oss-upload');?>: <code>1 ~ 99</code></small></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Featured Image','oss-upload')?></th>
        <td>
            <p><label>
                <input type="text" name="ouop[oss_size_width]" size="10" value="<?php echo OU1141("\x6f\163\x73\x5f\163\151\x7a\145\x5f\x77\151\x64\x74\x68")?>" /> x
                <input type="text" name="ouop[oss_size_height]" size="10" value="<?php echo OU1141("\157\163\x73\x5f\163\x69\x7a\145\x5f\150\145\151\x67\150\x74")?>" />
            </label></p>
            <p <?php OU1170("\157\163\x73\137\165\x70\154\x6f\141\144\x5f\x64\145\163\143");?>><small><?php _e('Set the featured image dimensions when thumbnails enabled (width x height)','oss-upload');?>: <code>800</code> x <code>450</code></small></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Style Separator','oss-upload')?></th>
        <td>
            <p><label><input type="text" name="ouop[oss_style_separator]" size="60" value="<?php echo OU1141("\x6f\x73\x73\137\163\x74\x79\154\145\137\163\x65\160\x61\x72\141\164\157\x72")?>" /> <?php echo OU1172("\57\x2f\x68\145\x6c\x70\x2e\x61\x6c\x69\x79\x75\x6e\x2e\x63\157\155\57\144\157\x63\x75\x6d\145\156\x74\x5f\x64\x65\x74\141\x69\x6c\x2f\x34\x38\x38\70\x34\x2e\x68\x74\x6d\154","\77","\142\x6c\141\x6e\x6b");?></label></p>
            <p <?php OU1170("\x6f\163\163\137\165\160\154\157\141\144\x5f\144\x65\x73\x63");?>><small><?php _e('Custom style separator for OSS Image Service style','oss-upload')?>: <code>?x-oss-process=style/</code> <code>-</code> <code>_</code> <code>/</code> <code>!</code></small></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Fullsize Style','oss-upload')?></th>
        <td>
            <p><label><input type="text" name="ouop[oss_fullsize_style]" size="60" value="<?php echo OU1141("\x6f\163\163\137\146\165\154\x6c\x73\x69\x7a\x65\137\163\164\x79\154\145")?>" />
            <?php echo OU1172("\57\57\150\145\x6c\160\x2e\x61\154\x69\x79\x75\x6e\x2e\143\x6f\x6d\57\x64\x6f\x63\x75\x6d\145\x6e\x74\x5f\144\145\x74\x61\x69\x6c\57\x34\64\x36\70\x36\x2e\x68\x74\x6d\x6c","\x3f","\x62\x6c\141\156\x6b");?></label></p>
            <p <?php OU1170("\157\x73\163\x5f\x75\x70\154\x6f\x61\144\137\144\x65\x73\x63");?>><small><?php _e('Default full size image style for OSS Image Service','oss-upload')?>: <code>{default}</code></small></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('GIF Style','oss-upload')?></th>
        <td>
            <p><label><input name="ouop[oss_gif]" type="checkbox" value="1" <?php checked(OU1141("\x6f\x73\163\x5f\147\151\146"),1);?> />
            <?php _e('Using special OSS Image Service style for <code>GIF</code> format','oss-upload')?> <?php echo OU1172("\57\x2f\150\145\x6c\160\56\x61\154\x69\x79\165\156\56\143\x6f\x6d\57\x64\x6f\143\x75\x6d\145\x6e\164\x5f\144\x65\x74\x61\151\154\x2f\x34\x34\x39\x35\x37\56\x68\x74\155\154","\x3f","\142\x6c\x61\156\153");?></label></p>
            <p <?php OU1170("\x6f\163\163\x5f\x75\x70\x6c\x6f\141\x64\137\x64\x65\x73\x63");?>><small><?php _e('If gif have no animation effect, check this and set extra style on OSS','oss-upload')?>: <code>{gif}</code> 
                <?php if(OU1141("\x6f\x73\x73\x5f\x66\x75\x6c\x6c\x73\x69\x7a\x65\137\x73\x74\x79\x6c\x65")):?>
                    <code>{default_gif}</code>
                <?php endif;?>
            </small></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Auto Compress','oss-upload')?></th>
        <td>
            <p><label><input name="ouop[oss_webp]" type="checkbox" value="1" <?php checked(OU1141("\157\163\x73\x5f\167\x65\x62\x70"),1);?> />
            <?php _e('Compress as <code>WebP</code> format automatically if browser support','oss-upload')?> <?php echo OU1172("\57\x2f\x68\x65\x6c\160\x2e\x61\154\151\171\165\x6e\x2e\143\x6f\155\x2f\x64\x6f\x63\x75\x6d\x65\156\164\x5f\x64\145\x74\x61\x69\154\57\64\64\67\60\x33\x2e\150\164\155\x6c","\x3f","\142\154\x61\x6e\x6b");?></label></p>
            <p <?php OU1170("\x6f\163\x73\x5f\x75\160\x6c\x6f\141\x64\137\x64\x65\163\x63");?>><small><?php _e('Require extra style to be set on OSS when using styles for Image Service','oss-upload')?>: <code>{style}_webp</code></small></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Lazyload','oss-upload')?></th>
        <td>
            <p><label><input name="ouop[oss_lazyload]" type="checkbox" value="1" <?php checked(OU1141("\x6f\x73\163\x5f\x6c\x61\x7a\x79\154\x6f\x61\x64"),1);?> />
            <?php _e('Delay loading of images in long web pages','oss-upload')?> 
            <?php echo OU1172("\x2f\57\160\x6c\x75\147\x69\x6e\x73\x2e\x6a\161\x75\145\x72\171\x2e\x63\157\155\57\x6c\141\x7a\171\x6c\x6f\x61\x64\57","\x3f","\x62\x6c\x61\x6e\153");?></label></p>
            <p <?php OU1170("\157\x73\x73\x5f\165\x70\x6c\x6f\141\144\x5f\144\x65\x73\143");?>><small><?php _e('Images outside of viewport wont be loaded before user scrolls to them','oss-upload')?></small></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Lazyload URL','oss-upload')?></th>
        <td>
            <p><label><input type="text" name="ouop[oss_lazyurl]" size="60" value="<?php echo OU1141("\x6f\x73\x73\137\154\x61\x7a\x79\165\x72\x6c")?>" /></label></p>
            <p <?php OU1170("\x6f\163\x73\x5f\x75\x70\x6c\x6f\x61\x64\x5f\x64\x65\x73\x63");?>><small><?php _e('Default image url for lazyload, could be with Image Service suffix, or base64 data, or normal url. <code>{IMG}</code> means original','oss-upload')?></small></p>
            <div <?php OU1170("\x6f\x73\x73\137\165\160\x6c\157\x61\144\137\x65\170\x61\155\x70\x6c\x65");?>>
            <p><small><code>{IMG}?x-oss-process=image/quality,q_10/resize,m_lfit,w_20</code></small></p>
            <p><small><code>{IMG}<?php echo OU1141("\157\x73\163\137\x73\x74\x79\x6c\x65\x5f\x73\145\x70\x61\x72\x61\x74\x6f\162")?trim(OU1141("\157\163\x73\x5f\x73\x74\x79\x6c\x65\137\x73\x65\x70\141\x72\x61\x74\x6f\x72")):"\x3f\x78\x2d\157\x73\163\55\x70\x72\x6f\143\145\x73\x73\x3d\163\164\171\x6c\145\57";?>lazyload-style</code></small></p>
            <p><small><code>data:image/gif;base64,R0lGODdhAQABAPAAAMPDwwAAACwAAAAAAQABAAACAkQBADs=</code></small></p>
            <p><small><code>//img.domain.com/xxx/lazyload.png</code></small></p>
            </div>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Upload Mimes','oss-upload')?></th>
        <td>
            <p><label><input name="ouop[upload_mimes]" size="60" value="<?php echo OU1141("\x75\160\154\x6f\x61\144\x5f\155\x69\x6d\x65\163")?>" />
                <?php echo OU1172("\x2f\x2f\x63\x6f\x64\145\x78\56\x77\x6f\162\144\160\162\x65\163\x73\56\x6f\x72\x67\x2f\x46\x75\156\143\x74\151\x6f\x6e\x5f\x52\x65\x66\145\162\145\x6e\143\145\x2f\147\145\164\x5f\x61\x6c\x6c\x6f\167\145\144\x5f\x6d\151\155\145\x5f\x74\x79\x70\x65\x73","\x3f","\142\x6c\x61\x6e\153");?></label></p>
            <p <?php OU1170("\157\163\x73\137\x75\x70\x6c\x6f\x61\x64\137\144\145\x73\143");?>><small><?php _e('Add file extensions and mime types to the allowed upload list','oss-upload')?>: <code>flac=audio/x-flac</code></small></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('URL Fixer','oss-upload')?></th>
        <td>
            <p><label><input name="ouop[oss_url_find]" size="60" value="<?php echo OU1141("\x6f\163\x73\137\x75\x72\154\137\x66\x69\x6e\x64")?>" /></label></p>
            <p><label><input name="ouop[oss_url_replace]" size="60" value="<?php echo OU1141("\157\x73\x73\x5f\x75\x72\x6c\137\x72\145\160\x6c\141\143\145")?>" /></label></p>
            <p <?php OU1170("\x6f\x73\163\x5f\x75\160\x6c\157\141\x64\x5f\144\x65\163\x63");?>><small><?php _e('Find and replace whatever strings you want to fix the attachment url','oss-upload')?>: <code>http||upload</code> <code>https||uploads</code></small></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Remote Image','oss-upload')?></th>
        <td>
            <p><label><input name="ouop[oss_remote]" type="checkbox" value="1" <?php checked(OU1141("\x6f\163\x73\x5f\162\x65\155\x6f\x74\145"),1);?> />
            <?php _e('Enable remote images autosave when edit post/page','oss-upload')?></label></p>
        </td></tr>
        <tr valign="top">
        <th scope="row"><?php _e('Local Backup','oss-upload')?></th>
        <td>
            <p><label><input name="ouop[oss_backup]" type="checkbox" value="1" <?php checked(OU1141("\x6f\x73\x73\137\x62\x61\x63\153\x75\160"),1);?> />
            <?php _e('Backup original image to local storage','oss-upload')?> <small><code>
            <?php
$OU1017=wp_get_upload_dir();
echo isset($OU1017["\x64\x65\x66\x61\x75\x6c\164"]["\x62\x61\x73\x65\x64\x69\162"])?$OU1017["\x64\145\x66\x61\165\x6c\164"]["\x62\x61\163\x65\x64\x69\162"]:$OU1017["\x62\141\163\x65\x64\x69\x72"];
?>
            </code></small></label></p><br />
            <?php
echo OU1172("\x3f\160\141\x67\x65\x3d\157\163\x73\x2d\x75\x70\154\x6f\x61\x64\x26\x73\x65\x74\x74\151\x6e\x67\163\x2d\x75\x70\144\x61\164\145\x64\75\x73\x79\x6e\x63",__('Upload Missing Attachment','oss-upload'),"\142\x75\x74\x74\x6f\x6e");
echo OU1172("\x3f\x70\141\x67\x65\x3d\157\163\x73\x2d\165\x70\154\x6f\x61\144\x26\x73\145\164\x74\x69\x6e\x67\163\x2d\165\160\x64\x61\x74\145\x64\75\x75\160\154\x6f\141\x64",__('Upload Whole Local Storage','oss-upload'),"\x62\x75\164\x74\x6f\156");
?>
        </td></tr>
        </table>
        <script type="text/javascript">
            jQuery(':password').focus(
                function(){ jQuery(this).get(0).type = 'text'; }
            ).blur(
                function(){ jQuery(this).get(0).type = 'password'; }
            );
            jQuery('.form-table :input:lt(6):gt(2)').blur(function(){
                if(jQuery(this).val().indexOf(jQuery(this).attr('placeholder').substr(0,4))!=0) jQuery(this).val('');
            });
            jQuery('a[href*="settings-updated=clean"]').click(function(){
                return confirm("<?php _e('This action would clean all thumbnails including local and OSS that filename like photo-800x600.png, cannot be undone, comfirm to process?','oss-upload');?>");
            });
            jQuery('a[href*="settings-updated=upload"]').click(function(){
                return confirm("<?php _e('This action would upload local storage directory to OSS, override if file exists, might take several minutes, comfirm to process?','oss-upload');?>");
            });
            jQuery('a[href*="settings-updated=sync"]').click(function(){
                return confirm("<?php _e('This action would upload attachment from local storage that missing in OSS, might take several minutes, comfirm to process?','oss-upload');?>");
            });
            jQuery('a[href*="settings-updated=reset"]').click(function(){
                return confirm("<?php _e('This action would regenerate metadata of all attachment in OSS, might take several minutes, comfirm to process?','oss-upload');?>");
            });
        </script>
        <?php submit_button();?>
    </div>
    <?php
}

?>
